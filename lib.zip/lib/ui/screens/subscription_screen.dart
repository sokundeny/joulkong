import 'package:flutter/material.dart';
import 'package:joulkong/model/subscribtion.dart';
import 'package:joulkong/ui/theme/theme.dart';

class SubscriptionScreen extends StatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  PassType? selectedPlan;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text("Subscription"),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Choose Your Plan",
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            const SizedBox(height: 8),

            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                "Select a subscription to start riding",
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),

            const SizedBox(height: 20),  
            Expanded(
              child: ListView(
                children: [
                  _planCard(
                    type: PassType.single,
                    title: "Single Ride",
                    price: "\$1.50",
                    features: ["1 ride only", "Basic access"],
                  ),
                  _planCard(
                    type: PassType.daily,
                    title: "Day Pass",
                    price: "\$3.00",
                    features: ["Unlimited rides", "24 hours"],
                  ),
                  _planCard(
                    type: PassType.weekly,
                    title: "Week Pass",
                    price: "\$10.00",
                    features: ["Unlimited rides", "7 days access"],
                  ),
                  _planCard(
                    type: PassType.monthly,
                    title: "Monthly",
                    price: "\$30.00",
                    features: ["Unlimited rides", "Priority bikes"],
                    highlight: true,
                  ),
                ],
              ),
            ),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: selectedPlan == null
                    ? null
                    : () {
                        Navigator.pop(context, selectedPlan);
                      },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.black,
                  padding: const EdgeInsets.all(16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
                child: const Text("Continue"),
              ),
            )
          ],
        ),
      ),
    );
  }
  Widget _planCard({
    required PassType type,
    required String title,
    required String price,
    required List<String> features,
    bool highlight = false,
  }) {
    final isSelected = selectedPlan == type;

    return GestureDetector(
      onTap: () {
        setState(() => selectedPlan = type);
      },
      child: Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: isSelected ? Colors.black : Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: isSelected ? Colors.black : Colors.grey.shade300,
            width: 1.5,
          ),
          boxShadow: [
            if (!isSelected)
              const BoxShadow(
                color: Colors.black12,
                blurRadius: 6,
                offset: Offset(0, 3),
              )
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            /// TOP ROW
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isSelected ? Colors.white : Colors.black,
                  ),
                ),
                Text(
                  price,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: isSelected
                        ? Colors.white
                        : AppTheme.secondaryColor,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 10),
            ...features.map(
              (f) => Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  "• $f",
                  style: TextStyle(
                    color:
                        isSelected ? Colors.white70 : Colors.grey[700],
                  ),
                ),
              ),
            ),
            if (highlight)
              Container(
                margin: const EdgeInsets.only(top: 10),
                padding: const EdgeInsets.symmetric(
                    horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: const Text(
                  "Best Value",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              )
          ],
        ),
      ),
    );
  }
}