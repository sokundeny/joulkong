
import 'package:flutter/material.dart';
import 'package:joulkong/data/repositories/stations/station_repository.dart';
import 'package:joulkong/data/repositories/user/user_repository.dart';
import 'package:joulkong/model/station.dart';
import 'package:joulkong/model/subscribtion.dart';
import 'package:joulkong/ui/screens/booking/view_model/booking_view_model.dart';
import 'package:joulkong/ui/screens/subscription_screen.dart';
import 'package:joulkong/ui/theme/theme.dart';
import 'package:provider/provider.dart';

class BookingScreen extends StatelessWidget {
  final Station station;

  const BookingScreen({super.key, required this.station});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => BookingViewModel(
        stationRepo: context.read<StationRepository>(),
        userRepo: context.read<UserRepository>(),
        station: station,
      ),
      child: _BookingContent(station: station),
    );
  }
}

class _BookingContent extends StatelessWidget {
  final Station station;
  const _BookingContent({required this.station});

  @override
  Widget build(BuildContext context) {
    final vm = context.watch<BookingViewModel>();

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          /// HANDLE BAR
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          const SizedBox(height: 16),
          _StationHeader(station: station),

          const SizedBox(height: 20),

          _buildBody(context, vm),
        ],
      ),
    );
  }

  Widget _buildBody(BuildContext context, BookingViewModel vm) {
    switch (vm.step) {
      case BookingStep.loadingUser:
      case BookingStep.booking:
        return const Padding(
          padding: EdgeInsets.all(40),
          child: CircularProgressIndicator(color: AppTheme.primaryColor),
        );

      case BookingStep.selectPass:
        return _PassSelectionView(vm: vm);

      case BookingStep.selectBike:
        return _BikeListView(vm: vm);

      case BookingStep.success:
        return _SuccessView(vm: vm);

      case BookingStep.error:
        return Text('Error: ${vm.errorMessage}');
    }
  }
}

class _StationHeader extends StatelessWidget {
  final Station station;

  const _StationHeader({required this.station});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        /// Bike Circle
        Container(
          width: 70,
          height: 70,
          decoration: BoxDecoration(
            color: Colors.black,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.pedal_bike, color: Colors.white),
                Text(
                  "${station.availableBikeCount}/${station.bikes.length}",
                  style: const TextStyle(
                      color: Colors.white, fontSize: 10),
                )
              ],
            ),
          ),
        ),

        const SizedBox(width: 16),

        /// Info
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(station.name,
                style:
                    const TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 4),
            const Text("280m • 4 min walk",
                style: TextStyle(color: Colors.grey)),
          ],
        )
      ],
    );
  }
}
class _PassSelectionView extends StatelessWidget {
  final BookingViewModel vm;
  const _PassSelectionView({required this.vm});

  @override
  Widget build(BuildContext context) {
    final passes = [
      (PassType.single, 'Single Ride', '\$1.50'),
      (PassType.daily, 'Day Pass', '\$3.00'),
      (PassType.weekly, 'Week Pass', '\$10.00'),
      (PassType.monthly, 'Month Pass', '\$30.00'),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Choose a Pass",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),

        const SizedBox(height: 6),

        Text(
          "Select a plan to continue booking",
          style: TextStyle(color: Colors.grey[600], fontSize: 13),
        ),

        const SizedBox(height: 16),

        ...passes.map((p) {
          return GestureDetector(
            onTap: () async {
              final selected = await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const SubscriptionScreen(),
                ),
              );
              if (selected != null) {
                vm.purchasePass(selected);
              }
            },
            child: Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black12),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  )
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  /// LEFT
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        p.$2,
                        style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Tap to view details",
                        style: TextStyle(
                          color: Colors.grey[500],
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),

                  /// RIGHT
                  Text(
                    p.$3,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          );
        }),
      ],
    );
  }
}

class _BikeListView extends StatefulWidget {
  final BookingViewModel vm;

  const _BikeListView({required this.vm});

  @override
  State<_BikeListView> createState() => _BikeListViewState();
}

class _BikeListViewState extends State<_BikeListView> {
  String? selectedBikeId;

  @override
  Widget build(BuildContext context) {
    final bikes = widget.vm.availableBikes;

    return Column(
      children: [
        const Align(
          alignment: Alignment.centerLeft,
          child: Text(
            "Available Bikes",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),

        const SizedBox(height: 12),

        /// BIKE LIST
        ...bikes.map((bike) {
          final isSelected = selectedBikeId == bike.id;

          return GestureDetector(
            onTap: () {
              setState(() => selectedBikeId = bike.id);
            },
            child: Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: isSelected ? Colors.black : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.black12),
              ),
              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Text(bike.id),
                      const SizedBox(width: 10),
                      Icon(Icons.pedal_bike,
                          color: isSelected
                              ? Colors.white
                              : Colors.black),
                    ],
                  ),
                  Text("Available",
                      style: TextStyle(
                          color: isSelected
                              ? Colors.white
                              : Colors.grey)),
                ],
              ),
            ),
          );
        }),

        const SizedBox(height: 16),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton(
            onPressed: selectedBikeId == null
                ? null
                : () => widget.vm.bookBike(selectedBikeId!),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.black,
              padding: const EdgeInsets.all(16),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
            child: const Text("Rent Now"),
          ),
        )
      ],
    );
  }
}

// SUCCESS UI
class _SuccessView extends StatelessWidget {
  final BookingViewModel vm;

  const _SuccessView({required this.vm});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Icon(Icons.check_circle,
            color: Colors.black, size: 60),
        const SizedBox(height: 12),
        const Text("Bike Booked!",
            style:
                TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text("Bike ${vm.bookedBike?.id} reserved"),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: () => Navigator.pop(context),
          child: const Text("Done"),
        )
      ],
    );
  }
}